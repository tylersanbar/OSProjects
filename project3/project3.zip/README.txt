Tyler Sanbar project 3
Did not consult peers
Did not consult outside resources
