Tyler Sanbar project 3
Did not consult peers
Consulted https://www.benjaminwuethrich.dev/2015-03-07-sorting-strings-in-c-with-qsort.html for solution to strcmp wrapping, used code in project
