#define LEN 12

typedef struct
{
  int a;
  float b;
  char c[LEN];
  int d;
} VALUES;

