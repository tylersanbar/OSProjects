#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char** argv)
{
  // Open for read.  R/W by user only
  int fd = open("myfile.out", O_RDONLY);
  int offset;
  
  if(fd == -1) {
    perror("Unable to open file");
    exit(-1);
  };

  // Successfully opened file

  // Read an int
  int i;

  if(read(fd, &i, sizeof(i)) != sizeof(i))  {
    perror("Read error\n");
    exit(-1);
  }
  offset = lseek(fd, 0, SEEK_CUR);
  //
  printf("Got: %d (%d)\n", i, offset);

  // Read the next int
  if(read(fd, &i, sizeof(i)) != sizeof(i))  {
    perror("Read error\n");
    exit(-1);
  }

  //
  offset = lseek(fd, 0, SEEK_CUR);
  printf("Got: %d (%d)\n", i, offset);

  
  
  float f;
  if(read(fd, &f, sizeof(f)) != sizeof(f))  {
    perror("Read error\n");
    exit(-1);
  }

  //
  offset = lseek(fd, 0, SEEK_CUR);
  printf("Got: %f (%d)\n", f, offset);
  
  // Close the file
  if(close(fd) != 0) {
    perror("Close error");
    exit(-1);
  }

  return(0);

}
