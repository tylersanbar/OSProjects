#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include "mystruct.h"

int main(int argc, char** argv)
{
  VALUES v;

  // Open for write and create.  R/W by user only
  int fd = open("myfile.out", O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);

  if(fd == -1) {
    perror("Unable to open file");
    exit(-1);
  };

  // Successfully opened file

  v.a = 5;
  v.b = 3.1892131;
  strncpy(v.c, "hello", LEN-1);
  v.c[LEN-1] = 0;
  v.d = -1;
  
  if(write(fd, &v, sizeof(VALUES)) != sizeof(VALUES)) {
    perror("Write");
    exit(-1);
  }

  // Second record
  v.a = 1138;
  v.b = 6.28318;
  strncpy(v.c, "world", LEN-1);
  v.c[LEN-1] = 0;
  v.d = -10;
  
  if(write(fd, &v, sizeof(VALUES)) != sizeof(VALUES)) {
    perror("Write");
    exit(-1);
  }
  
  // Close the file
  if(close(fd) != 0) {
    perror("Close error");
    exit(-1);
  }

  return(0);

}
