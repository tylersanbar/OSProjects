#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include "mystruct.h"

int main(int argc, char** argv)
{
  VALUES v;

  // Open for write and create.  R/W by user only
  int fd = open("myfile.out", O_RDONLY);

  if(fd == -1) {
    perror("Unable to open file");
    exit(-1);
  };

  // Successfully opened file
  int ret;

  do {
    ret = read(fd, &v, sizeof(VALUES));
    if(ret < 0) {
      perror("read");
      exit(-1);
    }else if(ret == sizeof(VALUES)){
      printf("Got: %d %f %s %d\n", v.a, v.b, v.c, v.d);
    }
  }while(ret == sizeof(VALUES));

  
  // Close the file
  if(close(fd) != 0) {
    perror("Close error");
    exit(-1);
  }

  return(0);

}
