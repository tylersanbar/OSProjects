#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char** argv)
{
  // Open for write and create.  R/W by user only
  int fd = open("myfile.out", O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);

  if(fd == -1) {
    perror("Unable to open file");
    exit(-1);
  };

  // Successfully opened file
  int i = 5;

  if(write(fd, &i, sizeof(i)) != sizeof(i)){
    perror("Write error");
    exit(-1);

  }

  i = -1;

  if(write(fd, &i, sizeof(i)) != sizeof(i)){
    perror("Write error");
    exit(-1);

  }

  float f = 6.283185;
  
  if(write(fd, &f, sizeof(f)) != sizeof(f)){
    perror("Write error");
    exit(-1);
  }

  // Close the file
  if(close(fd) != 0) {
    perror("Close error");
    exit(-1);
  }

  return(0);

}
