#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(int argc, char** argv)
{
  int status;

  int i = 5;
  
  int pid = fork();

  if(pid == -1) {
    perror("fork() error");
    exit(-1);
  }else if(pid == 0) {
    // This is the child process
    i = 7;

    printf("I am the child\n");
    sleep(10);
    printf("Child done (%d)\n", i);
  }else{
    // The parent process
    printf("I am the parent of process %d\n", pid);
    sleep(8);
    printf("Waiting for the child to terminate.\n");
    wait(NULL);
    printf("Parent done (%d)\n", i);
  }
  
  exit(0);
}
