#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(int argc, char** argv)
{
  int i = 5;

  int ret = system("wc Makefile fork_testaa.c");
  printf("Child returned: %d\n", ret);
  
  exit(0);
}
