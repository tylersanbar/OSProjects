#include <stdio.h>
#include <string.h>

int foo(int x, char y, char * z)
{
  printf("FOO\n");
  printf("%d %c %s\n", x, y, z);
  
  x += 3;
  y += 1;

  strcpy(z, "hi");
  
  printf("%d %c %s\n", x, y, z);

  printf("FOO END\n");

  return 0;
}


int foo2(int *x, char *y, char * z)
{
  printf("FOO\n");
  printf("%d %c %s\n", *x, *y, z);
  
  *x += 3;
  *y += 1;

  strcpy(z, "hi");
  
  printf("%d %c %s\n", *x, *y, z);

  printf("FOO END\n");

  return 0;
}

char * bar()
{
  char tmp[] = "hello";
  char *buf = malloc(strlen(tmp)+1);
  strcpy(buf, tmp);
  
  return buf;
};

int main(int argc, char** argv)
{
  int a = 2;
  char b = 'A';
  char c[] = "foobar";
  char *d;

  char **arg;
  char *table[] = {"one", "two", "three", "END"};

  printf("SIZES: %ld %ld %ld\n", sizeof(int), sizeof(char), sizeof(char*));
	 
  //printf("a: %lx\n", (unsigned long) &a);
  //printf("b: %lx\n", (unsigned long) &b);
  //printf("c: %lx\n", (unsigned long) c);

  //foo(a, b, c);
  //foo2(&a, &b, c);
  d = bar();
  
  //printf("%d %c %s\n", a, b, c);
  printf("BAR: %s\n", d);
  free(d);

  // arg = first string in the table
  arg = table;
  
  // print all elements in the table
  while(strcmp(*arg, "END")) {
    printf("%s\n", *arg);
    *arg++;
  }
  
  // alternative print of elements
  for(int i = 0; strcmp(table[i], "END")  ; ++i) {
    printf("%s\n", table[i]);
  }
};
