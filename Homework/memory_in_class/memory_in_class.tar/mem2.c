#include <stdio.h>
#include <string.h>
#include <stdlib.h>

const int BUFSIZE = 20;

//#define BUFSIZE 20

int main(int argc, char** argv)
{
  float a = 3.14159;
  unsigned char *b = (unsigned char*) &a;
  unsigned char buf[BUFSIZE];

  for(int i = 0; i < BUFSIZE; ++i) {
    buf[i] = 0;
  }

  for(int i = 0; i < sizeof(a); ++i) {
    printf("%d: %x\n", i, b[i]);
  }

  memcpy(&(buf[10]), b, sizeof(a));

  for(int i = 0; i < BUFSIZE; ++i) {
    printf("%d: %x\n", i, buf[i]);
  }

  
};
