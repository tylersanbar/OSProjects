#include <stdio.h>
#include <string.h>


int foo(char *s)
{
  fprintf(stderr, "POINTER: %lx\n", (unsigned long) s);
  if(strcmp(s, "million") == 0)
    {
      fprintf(stderr, "found million\n");
    }

  return 0;
}

int main(int argc, char** argv)
{
  char s[] = "foobar";
  int a = 8;
  int b = 42;
  char *s2; // = s;
  
  printf("%s\n", s);
  printf("%c\n", s[0]);
  printf("%c\n", s[1]);
  printf("%s\n", &(s[3]));

  s[4] = '#';
  printf("%s\n", s);

  //s[8] = '$';
  printf("%s\n", s);
  
  foo(s2);
  
  printf("%d %d\n", a, b);
};
