#include "my_input.h"

int prompt_char(char *strg)
{
  printf("%s: ", strg);
  return getchar();
}
