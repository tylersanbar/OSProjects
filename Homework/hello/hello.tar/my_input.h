#include <stdio.h>
int prompt_char(char *strg);
