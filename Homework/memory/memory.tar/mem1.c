#include <stdio.h>

/**
   Parameter passing by value.

   Passing pointers. 
 */
void foo(int x, char y, char* z)
{
  printf("FOO\n");
  printf("%d %c %s\n", x, y, z);
  printf("%x %x %x\n", &x, &y, z);
  x = 5;
  y = 'z';
  //sprintf(z, "hi");
  strncpy(z, "hi", 3);
  printf("%d %c %s\n", x, y, z);
  printf("DONE WITH FOO\n");
}


void foo2(int *x, char y, char* z)
{
  printf("FOO2\n");
  printf("%d %c %s\n", *x, y, z);
  printf("%x %x %x\n", x, &y, z);
  *x = 5;
  y = 'z';
  sprintf(z, "hi");
  printf("%d %c %s\n", *x, y, z);
  printf("DONE WITH FOO2\n");
}

int main(int argc, char** argv)
{
  int a = 2;
  char b = 'a';
  char c[] = "foobar";

  printf("%d %c %s\n", a, b, c);
  printf("%x %x %x\n", &a, &b, c);
  foo(a,b,c);
  printf("###\n");
  printf("%d %c %s\n", a, b, c);

  foo2(&a, b, c);
  printf("%d %c %s\n", a, b, c);
}
