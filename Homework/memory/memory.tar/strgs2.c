#include <stdio.h>

/**
   String representation

 */

int main(int argc, char** argv)
{
  char * table[] = {"foo", "bar", "foobar"};

  for(int i = 0; i < 3; ++i) {
    printf("Item %d: %s\n", i, table[i]);
  }

}
