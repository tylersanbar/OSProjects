#include <stdio.h>
#include <string.h>

/**
   Structures

 */

struct my_struct_s
{
  int a;
  char b;
  char c[4];
};

typedef struct my_struct_s my_struct;

void foo(my_struct *x) {
  printf("FOO\n");
  printf("Mem: %x %x %x %x\n", x, &x->a, &x->b, &x->c);
  printf("%d %c %s\n", x->a, x->b, x->c);
  x->b = 'x';
  printf("FOO END\n");

};

int main(int argc, char** argv)
{
  my_struct a;
  a.a = 3;
  a.b = 'c';
  strcpy(a.c, "oy");

  printf("%d %c %s\n", a.a, a.b, a.c);
  printf("Mem: %x %x %x %x\n", &a, &a.a, &a.b, &a.c);
  foo(&a);

  printf("%d %c %s\n", a.a, a.b, a.c);
}
