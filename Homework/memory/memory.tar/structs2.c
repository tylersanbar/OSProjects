#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/**
   Structures

 */

struct my_struct_s
{
  int a;
  char b;
  char c[4];
};

typedef struct my_struct_s my_struct;

int main(int argc, char** argv)
{
  my_struct *a;

  // Dynamic allocaion of space
  a = malloc(sizeof(my_struct));
  a->a = 3;
  a->b = 'c';
  strcpy(a->c, "oy");

  printf("%d %c %s\n", a->a, a->b, a->c);

  // DON'T FORGET!
  free(a);
}
