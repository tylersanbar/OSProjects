#include <stdio.h>

/**
   String representation

 */

int main(int argc, char** argv)
{
  char s[] = "foobar";

  printf("%s\n", s);

  printf("%c\n", s[0]);

  printf("%c\n", s[1]);

  s[4] = '#';

  printf("%s\n", s);

  // Cause memory violation
  /*
    
  s[8] = '#';

  printf("%s\n", s);
  */

  char *p = s;
  printf("%c\n", *p);
  ++p;
  printf("%c\n", *p);
  ++p;
  printf("%c\n", *p);

  printf("ALL:\n");
  for(p = s; *p; ++p) {
    printf("#%c\n", *p);
  }

  printf("####\n");
  printf("%s\n", &s[3]);
}
