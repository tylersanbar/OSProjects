#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void main(void) {
	printf("Hello World!\n");
}