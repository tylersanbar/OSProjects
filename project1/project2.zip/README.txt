Tyler Sanbar - Project 1
Got inspiration for testing loop from https://stackoverflow.com/questions/23800549/run-a-program-multiple-times-in-c
Figured out freopen from https://stackoverflow.com/questions/584868/rerouting-stdin-and-stdout-from-c

Did not consult peers.