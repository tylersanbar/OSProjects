Tyler Sanbar - Project 2
Did not consult online resources.
Did not consult peers.